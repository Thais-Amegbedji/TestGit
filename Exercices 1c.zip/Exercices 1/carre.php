<?php
$cote=5;
$perimetre=$cote*4;
$demiperimetre=$perimetre/2;
$aire=$cote*$cote;
$diagonale=$cote*sqrt(2);
echo "le perimetre est $perimetre"; echo "<br>";
echo "le demi perimetre est $demiperimetre"; echo "<br>";
echo "l'aire est $aire"; echo "<br>";
echo "la longueur de la diagonale est $diagonale"; echo "<br>";
?>