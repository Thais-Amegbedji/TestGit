<?php
$rayon=3;
define ("PI",3.14);
$circonference=2*PI*$rayon;
$aire=PI*$rayon*$rayon;
echo "la circonference est $circonference"; echo "<br>";
echo "l'aire est $aire"; echo "<br>";
?>