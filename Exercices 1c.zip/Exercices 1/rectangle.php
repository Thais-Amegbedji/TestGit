<?php
$longueur=6;
$largeur=4;
$perimetre=2*($longueur+$largeur);
$demiperimetre=$perimetre/2;
$aire=$longueur*$largeur;
$diagonale=sqrt($longueur*$longueur+$largeur*$largeur);
echo "le perimetre est $perimetre"; echo "<br>";
echo "le demi-perimetre est $demiperimetre"; echo "<br>";
echo "l'aire est $aire"; echo "<br>";
echo "la longueur de la diagonale est $diagonale"; echo "<br>";
?>